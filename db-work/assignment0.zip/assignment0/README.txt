1. Name: Kasper Allais
2. I am running psql on Arch Linux. I installed psql on my own machine.
3. The only challenge that I encountered was installing Global Protect because I had to find the name of the package. I also had to look up documentation on the \o command.
